module.exports = {
    ROUTES: {
        LOGIN: '/login',
        REGISTER: '/register'
    }
}